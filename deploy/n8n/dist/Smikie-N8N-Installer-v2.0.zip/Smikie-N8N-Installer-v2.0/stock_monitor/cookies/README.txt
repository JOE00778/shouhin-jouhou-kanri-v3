把供应商登录 cookies 放在这里。
具体文件命名见 ../scripts/scraper.py 顶部说明。
没有 cookies 也能跑，仅免登录公开页可访问。
